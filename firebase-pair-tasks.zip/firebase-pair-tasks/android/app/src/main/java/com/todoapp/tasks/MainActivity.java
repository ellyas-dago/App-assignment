package com.todoapp.tasks;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
